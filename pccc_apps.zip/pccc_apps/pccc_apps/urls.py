from django.urls import path
from django.contrib import admin
from gpa_calculator.views import IndexView, gpa_view


urlpatterns = [
    path('',IndexView.as_view(), name="index"),
    path('gpa/', gpa_view, name="gpa"),
    path('admin/', admin.site.urls),
    #path('gpa/projected', projected_gpa_view, name="projected_gpa"),
]

