from django.apps import AppConfig


class GpaCalculatorConfig(AppConfig):
    name = 'gpa_calculator'
