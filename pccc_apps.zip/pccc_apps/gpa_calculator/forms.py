from django import forms
from django.core.exceptions import ValidationError

class CurrentGPAForm(forms.Form):
	currentGPA = forms.FloatField(label='Current GPA',min_value=0, max_value=4, required=True, 
		  						  initial=0.0, widget=forms.NumberInput(attrs=
							   							{'class': 'form-control gpa',
							   							 'style': 'width: 63%;'}))

	creditsEarned = forms.FloatField(label='Credits Earned',min_value=0, required=True, 
									 initial=0.0, widget=forms.NumberInput(attrs=
							   							{'class': 'form-control gpa',
							   							 'style': 'width: 63%;'}))
class GPAForm(forms.Form):
	credits = forms.FloatField(label='Credits',min_value=1, max_value=7, required=True, initial='',
							   widget=forms.NumberInput(attrs=
							   							{'class': 'form-control gpa',
							   							 'style': 'width: 65%;'}))
	grade = forms.ChoiceField(label='Grade',  required = True, 
							  error_messages={'invalid': 'Please choose a grade'},
							  choices= [('--', '--'), ('A', 'A'),
	 ('A-', 'A-'), ('B+', 'B+'), ('B', 'B'), ('B-', 'B-'), ('C+', 'C+'),
	 ('C', 'C'), ('C-', 'C-'), ('D+', 'D+'), ('D', 'D'), ('F', 'F')], 
	 						  widget=forms.Select(attrs={'class': 'form-control gpa',
														'style': 'width: 65%;'}))

	def clean_grade(self):
		if (self.cleaned_data['grade'] == '--'):
			raise ValidationError(self.fields['grade'].error_messages['invalid'])
		return self.cleaned_data['grade']
