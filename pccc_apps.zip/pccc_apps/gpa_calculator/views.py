# -*- coding: utf-8 -*-
from __future__ import unicode_literals
from django.shortcuts import render, render_to_response
from django.views.generic.base import TemplateView
from django.views.generic.edit import FormView
from django.views import View
from gpa_calculator.forms import GPAForm, CurrentGPAForm
from django.urls import reverse
from django.forms import formset_factory

class IndexView(TemplateView):
    template_name = 'index.html'


def gpa_view(request):
    context = {}
    GPAFormSet = formset_factory(GPAForm)
    currentGPAForm = CurrentGPAForm()
    
    if request.method == "POST":
        gpa_formset = GPAFormSet(request.POST)
        currentGPAForm = CurrentGPAForm(request.POST)

        # Validating GPA Form    
        if gpa_formset.is_valid() and currentGPAForm.is_valid():

            currentGPA = currentGPAForm.cleaned_data['currentGPA']
            creditsEarned = currentGPAForm.cleaned_data['creditsEarned']

            gradePointsEarned = currentGPA * creditsEarned

            gradePoints = 0
            totalCredits = 0

            # Calculate GPA
            for form in gpa_formset:
                if form.cleaned_data:
                    
                    credits = form.cleaned_data['credits']
                    grade = form.cleaned_data['grade']
                    
                    if (grade == 'A'):
                        gradePoints += (credits*4.0)
                        totalCredits += credits

                    elif (grade=='A-'):
                        gradePoints += (credits*3.7)
                        totalCredits += credits

                    elif (grade=='B+'):
                        gradePoints += (credits*3.3)
                        totalCredits += credits

                    elif (grade=='B'):
                        gradePoints += (credits*3.0)
                        totalCredits += credits

                    elif (grade=='B-'):
                        gradePoints += (credits*2.7)
                        totalCredits += credits

                    elif (grade=='C+'):
                        gradePoints += (credits*2.3)
                        totalCredits += credits

                    elif (grade=='C'):
                        gradePoints += (credits*2.0)
                        totalCredits += credits

                    elif (grade=='C-'):
                        gradePoints += (credits*1.7)
                        totalCredits += credits

                    elif (grade=='D+'):
                        gradePoints += (credits*1.3)
                        totalCredits += credits

                    elif (grade=='D'):
                        gradePoints += (credits*1.0)
                        totalCredits += credits

                    elif (grade=='F'):
                        gradePoints += (credits*0.0)
                        totalCredits += credits
            
            if (totalCredits!=0):

                if currentGPA == 0:
                    projectedGPA = 0.0

                else:
                    projectedGPA = (gradePoints+gradePointsEarned)/(totalCredits+creditsEarned)
                    projectedGPA = round(projectedGPA, 2)

                semesterGPA = gradePoints/totalCredits
                semesterGPA = round(semesterGPA, 2)

            else:
                semesterGPA = 0
            
            context['current_gpa'] = currentGPA
            context['semester_gpa'] = semesterGPA
            context['raised_gpa'] = projectedGPA
            context['grade_points'] = round(gradePoints, 2)
            context['total_credits'] = totalCredits
            context['gpa_formset'] = gpa_formset
            context['currentGPAForm'] = currentGPAForm
            context['anchor'] = True

            


        # Form is NOT Valid
        else:
            # Return form back to user with the data and errors
            context['gpa_formset'] = gpa_formset
            context['currentGPAForm'] = currentGPAForm
            context['anchor'] = False

    # GET Request, return the form
    else:
        context['gpa_formset'] = formset_factory(GPAForm, extra=2)
        context['currentGPAForm'] = currentGPAForm
        
    return render(request, 'gpa.html', context)
