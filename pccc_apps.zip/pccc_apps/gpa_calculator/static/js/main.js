// Reset Form
function resetGPAForm() {
    var form = $('#gpa_form');
    $(form).find('input[type=number]').val('');
    $(form).find('select').val('--');
}

// Update course numbers
function updateCourseNumbers() {
    var forms = $('#form_set').find('.form-row');
    var formsLength = forms.length;
    for (var i=0; i < formsLength; i++) {
        var c_num = i + 1;
        $(forms.get(i)).find('#course_num').text('Course #' + c_num);
    }
}

// Add course
function addForm () {
    var form_idx = $('#id_form-TOTAL_FORMS').val();
    $('#form_set').append($('#empty_form').html().replace(/__prefix__/g, form_idx));
    $('#id_form-TOTAL_FORMS').val(parseInt(form_idx) + 1);
    updateCourseNumbers();
   
}

// Update the form ids
function updateElementIndex(el, prefix, ndx) {
    var id_regex = new RegExp('(' + prefix + '-\\d+)');
    var replacement = prefix + '-' + ndx;
    if ($(el).attr("for")) $(el).attr("for", $(el).attr("for").replace(id_regex, replacement));
    if (el.id) el.id = el.id.replace(id_regex, replacement);
    if (el.name) el.name = el.name.replace(id_regex, replacement);
}

// Remove form on click
function deleteForm(prefix, btn) {
    var total = parseInt($('#id_' + prefix + '-TOTAL_FORMS').val());
    if (total > 1){
        btn.closest('.form-row').remove();
        var forms = $('#form_set').find('.form-row');
        console.log(forms.length);
        $('#id_' + prefix + '-TOTAL_FORMS').val(forms.length);
        for (var i=0, formCount=forms.length; i<formCount; i++) {
            $(forms.get(i)).find(':input').each(function() {
                updateElementIndex(this, prefix, i);
            });
        }
        updateCourseNumbers();
    }
    return false;
}

// Direct user to Calculation Summary Seciton on valid submission
function goToCalcSummary() {
    window.location = '#calculate';
}